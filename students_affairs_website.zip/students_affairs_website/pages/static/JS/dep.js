let name = document.getElementById("name");
let id = document.getElementById("id");
let depart = document.getElementById("department");
let btn = document.getElementById("submit");


btn.addEventListener("click", (event) => {
  
  alert("The value of the department has been updated");
});
